﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace guiaN1
{
    internal class guiaN1
    {
        public static void Main(string[] args)
        {
            try
            {
                Ejecutar();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"\nError: {ex.Message}." +
                                $"\nClausura del Programa.");
            }
        }

        public static void Ejecutar()
        {
            int op;
            do
            {
                Console.WriteLine("\nAcciones Disponibles: " +
                                  "\n1. Calcular dobles de numeros." +
                                  "\n2. Hallar el número mayor." +
                                  "\n3. Promedio de dos cursos." +
                                  "\n4. Cerrar Programa.");
                Console.Write("Elija una una opción a ejecutar: ");
                op = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine();

                switch (op)
                {
                    case 1:
                        numDoble();
                        break;

                    case 2:
                        numMayor();
                        break;

                    case 3:
                        PromedioCursos();
                        break;

                    case 4:
                        Console.WriteLine("Cerrando Programa.");
                        break;

                    default:
                        Console.WriteLine("\nOpción Inválida.");
                        break;
                }

            } while (op != 4);
        }

        public static void numDoble()
        {
            int doble;
            int[] array = new int[5];

            //Iterador Repetitivo.
            for (int i = 0; i < 5; i++)
            {
                Console.Write($"Ingresar el dígito entero #{(i + 1)}: ");
                array[i] = Convert.ToInt32(Console.ReadLine());
            }

            Console.WriteLine();
            for (int i = 0; i < 5; i++)
            {
                doble = (array[i] * 2);
                Console.WriteLine($"El doble de {array[i]} es: " + doble + ".");
            }
            return;
        }

        public static void numMayor()
        {
            int mayor = 0, n, posicion = 0;
            int[] array;

            Console.WriteLine("\n2do Ejercicio: ");
            do
            {
                Console.Write("Ingrese el tamaño del Arreglo (1-10): ");
                n = Convert.ToInt32(Console.ReadLine());
                if (n <= 0 || n > 10)
                {
                    Console.WriteLine("\nTamaño admitido entre 1-10.");
                }
            } while (n <= 0 || n > 10);
            array = new int[n];


            for (int i = 0; i < array.Length; i++)
            {
                //do
                //{
                Console.Write($"Ingresar el dígito entero #{(i + 1)}: ");
                array[i] = Convert.ToInt32(Console.ReadLine());
                //if (array[i] < 0 || array[i] > 1000)
                //{
                //    Console.WriteLine("\nEl dígito debe ser mayor que '0' y menor que '1000'.");
                //}
                //} while (array[i] < 0 || array[i] > 1000);

                if (array[i] > mayor)
                {
                    mayor = array[i];
                    posicion = i;
                }
            }

            Console.Write("\n[");

            for (int i = 0; i < array.Length; i++)
            {
                if (i == (n - 1))
                {
                    Console.Write(array[i] + ".");
                }
                else
                {
                    Console.Write(array[i] + ", ");
                }
            }
            Console.WriteLine("]");

            Console.WriteLine($"\nEl numero mayor es: '{mayor}', posición casilla #{posicion + 1}.");
            //PREGUNTAR A LARIOS, ERROR DEL 'POSICION = I'.
            return;
        }

        public static void PromedioCursos()
        {
            /* Suma de notas y promedio, comparación con dos cursos
             2 vectores, (promedio / array.Length)*/
            double promedio1, promedio2;
            int n, suma1 = 0, suma2 = 0;
            int[] curso1;
            int[] curso2;
            do
            {
                Console.Write("Ingrese la cantidad de alumnos del Curso #1 (1-30): ");
                n = Convert.ToInt32(Console.ReadLine());
                if (n <= 0 || n > 30)
                {
                    Console.WriteLine("\nMín - 1 | Máx - 30.");
                }
            } while (n <= 0 || n > 30);
            curso1 = new int[n];


            for (int i = 0; i < curso1.Length; i++)
            {
                do
                {
                    Console.Write($"Ingresar la nota del Alumno #{(i + 1)}: ");
                    curso1[i] = Convert.ToInt32(Console.ReadLine());
                    if (curso1[i] < 0 || curso1[i] > 100)
                    {
                        Console.WriteLine("\nLa nota debe ser positiva y menor que '101'.");
                    }
                } while (curso1[i] < 0 || curso1[i] > 100);
                suma1 += curso1[i];
            }

            Console.WriteLine("\n¿Imprimir Calificaciones del Curso #1?");
            Console.Write("1. Sí | 2. No.\nElija una opción: ");
            int op = Convert.ToInt32(Console.ReadLine());
            if (op == 1)
            {
                Console.Write("\nNotas del Curso #1:\n[");

                for (int i = 0; i < curso1.Length; i++)
                {
                    if (i == (n - 1))
                    {
                        Console.Write(curso1[i] + ".");
                    }
                    else
                    {
                        Console.Write(curso1[i] + ", ");
                    }
                }
                Console.WriteLine("]");
            }
            promedio1 = (suma1 / curso1.Length);

            do
            {
                Console.Write("\nIngrese la cantidad de alumnos del Curso #2 (1-30): ");
                n = Convert.ToInt32(Console.ReadLine());
                if (n <= 0 || n > 30)
                {
                    Console.WriteLine("\nMín - 1 | Máx - 30.");
                }
            } while (n <= 0 || n > 30);
            curso2 = new int[n];


            for (int i = 0; i < curso2.Length; i++)
            {
                do
                {
                    Console.Write($"Ingresar la nota del Alumno #{(i + 1)}: ");
                    curso2[i] = Convert.ToInt32(Console.ReadLine());
                    if (curso2[i] < 0 || curso2[i] > 100)
                    {
                        Console.WriteLine("\nLa nota debe ser positiva y menor que '101'.");
                    }
                } while (curso2[i] < 0 || curso2[i] > 100);
                suma2 += curso2[i];
            }

            Console.WriteLine("\n¿Imprimir Calificaciones del Curso #2?");
            Console.Write("1. Sí | 2. No.\nElija una opción: ");
            op = Convert.ToInt32(Console.ReadLine());

            if (op == 1)
            {
                Console.Write("\n[");

                for (int i = 0; i < curso2.Length; i++)
                {
                    if (i == (n - 1))
                    {
                        Console.Write(curso2[i] + ".");
                    }
                    else
                    {
                        Console.Write(curso2[i] + ", ");
                    }
                }
                Console.WriteLine("]");
            }
            promedio2 = (suma2 / curso2.Length);

            string resultado = (promedio1 > promedio2) ? $"\nEl curso #1 tiene mejor promedio con {promedio1}." : $"\nEl curso #1 tiene mejor promedio con {promedio2}.";
            Console.WriteLine(resultado);
            return;
        }

        /*Autor: Mario Mena.
        Pdt: Veveve.*/
    }
}
